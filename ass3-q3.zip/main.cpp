#include <iostream>
using namespace std;

class Stack {
    char arr[100];
    int top;

public:
    Stack() { top = -1; }

    void push(char c)
    {
        if (top < 99) arr[++top] = c;
    }

    char pop() 
    {
        if (top >= 0) return arr[top--];
        return '\0'; 
    }

    char peek() 
    {
        if (top >= 0) return arr[top];
        return '\0';
    }

    bool isEmpty()
    {
        return top == -1;
    }
};

bool isBalanced(char ex[])
{
    Stack s;
    for (int i = 0; ex[i] != '\0'; i++) 
    {
        char c = ex[i];

        if (c == '(' || c == '{' || c == '[')
        {
            s.push(c);
        }
        else if (c == ')' || c == '}' || c == ']')
        {
            if (s.isEmpty()) return false; 

            char topChar = s.pop();
            if ((c == ')' && topChar != '(') ||
                (c == '}' && topChar != '{') ||
                (c == ']' && topChar != '['))
                {
                return false; 
            }
        }
    }

    return s.isEmpty(); 
}

int main() {
    char ex[100];
    cout << "Enter an expression: ";
    cin >> ex;

    if (isBalanced(ex))
        cout << "Parentheses are balanced." << endl;
    else
        cout << "Parentheses are NOT balanced." << endl;

    return 0;
}

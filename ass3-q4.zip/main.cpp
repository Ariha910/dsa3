#include <iostream>
#include <cstring>
using namespace std;

class Stack 
{
    char arr[100];
    int top;

public:
    Stack() { top = -1; }

    void push(char c) 
    {
        if (top < 99) 
        {
            top++;
            arr[top] = c;
        }
    }

    char pop()
    {
        if (top >= 0) 
        {
            return arr[top--];
        }
        return '\0';
    }

    char peek() 
    {
        if (top >= 0) return arr[top];
        return '\0';
    }

    bool isEmpty() 
    {
        return top == -1;
    }
};

int precedence(char op) 
{
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    if (op == '^') return 3;
    return 0;
}

bool isOperator(char c) 
{
    return (c == '+' || c == '-' || c == '*' || c == '/' || c == '^');
}


void infixToPostfix(char infix[], char postfix[]) {
    Stack s;
    int k = 0;

    for (int i = 0; infix[i] != '\0'; i++) {
        char c = infix[i];

        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) 
        {
            postfix[k++] = c;
        }
        
        else if (c == '(')
        {
            s.push(c);
        }
      
        else if (c == ')') 
        {
            while (!s.isEmpty() && s.peek() != '(') 
            {
                postfix[k++] = s.pop();
            }
            if (!s.isEmpty()) s.pop(); 
        }
        
        else if (isOperator(c)) {
            while (!s.isEmpty() && precedence(s.peek()) >= precedence(c)) {
                if (c == '^' && s.peek() == '^') break; 
                postfix[k++] = s.pop();
            }
            s.push(c);
        }
    }

    while (!s.isEmpty()) {
        postfix[k++] = s.pop();
    }

    postfix[k] = '\0';
}


int main() {
    char infix[100], postfix[100];
    cout << "Enter an infix expression: ";
    cin >> infix;

    infixToPostfix(infix, postfix);

    cout << "Postfix Expression: " << postfix << endl;
    return 0;
}

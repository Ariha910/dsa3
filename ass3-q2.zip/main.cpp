#include <iostream>
using namespace std;

class Stack {
    char *arr;
    int top;
    int size;

public:
    
    Stack(int size) {
      this -> size = size;
        arr = new char[size];
        top = -1;
    }

   
    void push(char c)
    {
        if (size - top>1)
        {
            top++;
            arr[top] = c;
            
        } 
        else 
        {
           cout << "Stack Overflow! Cannot push "  << endl;
        }
    }

 
    char pop() 
    {
        if (top>=0) {
           
           return arr[top--];
        } 
        else
        {
            cout << "stack underflow"<< endl;
            return '\0';
        }
    }

    
   bool isEmpty() 
   {
    return top == -1;
}
};
int main() {
    string str;
    cout << "Enter a string: ";
    cin >> str;

    int n = str.length();
    Stack s(n);

   
    for (int i = 0; i < n; i++) {
        s.push(str[i]);
    }

    
    string reversed = "";
    while (!s.isEmpty()) {
        reversed += s.pop();
    }

    cout << "Reversed string: " << reversed << endl;

    return 0;
}
#include <iostream>
#include <stack>
using namespace std;

void printNextGreater(int arr[], int n) {
    stack<int> s;
    int nge[n];   

    for (int i = n - 1; i >= 0; i--) {
        
        while (!s.empty() && s.top() <= arr[i]) {
            s.pop();
        }

       
        if (s.empty()) {
            nge[i] = -1;
        } else {
            nge[i] = s.top();
        }

        s.push(arr[i]);
    }

   
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " --> " << nge[i] << endl;
    }
}

int main() {
    int n;
    cout << "Enter number of elements: ";
    cin >> n;

    int arr[n];
    cout << "Enter " << n << " elements: ";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    printNextGreater(arr, n);

    return 0;
}

#include <iostream>
using namespace std;

class Stack {
    int *arr;
    int top;
    int size;

public:
    
    Stack(int size) {
      this -> size = size;
        arr = new int[size];
        top = -1;
    }

   
    void push(int value)
    {
        if (size - top>1)
        {
            top++;
            arr[top] = value;
            
        } 
        else 
        {
           cout << "Stack Overflow! Cannot push " << value << endl;
        }
    }

 
    void pop() {
        if (top>=0) {
           top--;
        } 
        else
        {
            cout << "stack underflow"<< endl;
        }
    }

    
    void isEmpty()
    {
        if (top == -1)
            cout << "Stack is empty." << endl;
        else
            cout << "Stack is not empty." << endl;
    }

   
    void isFull() 
    {
       if (size - top>1)
            cout << "Stack is not full." << endl;
        else
            cout << "Stack is full." << endl;
    }

  
    void display() 
    {
        if (top >=0) 
        {
             cout << "Stack elements (top → bottom):" << endl;
            for (int i = top; i >= 0; i--) 
            {
                cout << arr[i] << endl;
            }

         } 
         else
         {
            cout << "Stack is empty." << endl;
        }
    }

  
    void peek() 
    {
        if (top >=0&&top<size) 
        {
            cout<<arr[top];
            
        } 
        else 
        {
            cout << "Stack is empty " <<endl;
        }
    }
};
int main() {
    int size;
    cout << "Enter size of stack: ";
    cin >> size;

    Stack s(size);

    while (true) {
        cout << "\n--- Stack Menu ---" << endl;
        cout << "1. Push" << endl;
        cout << "2. Pop" << endl;
        cout << "3. isEmpty" << endl;
        cout << "4. isFull" << endl;
        cout << "5. Display" << endl;
        cout << "6. Peek" << endl;
        cout << "7. Exit" << endl;

        int choice;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                int val;
                cout << "Enter value to push: ";
                cin >> val;
                s.push(val);
                break;
            }
            case 2:
                s.pop();
                break;
            case 3:
                s.isEmpty();
                break;
            case 4:
                s.isFull();
                break;
            case 5:
                s.display();
                break;
            case 6:
                s.peek();
                break;
            case 7:
                cout << "Exiting program." << endl;
                return 0;
            default:
                cout << "Invalid choice! Try again." << endl;
        }
    }
}
